/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
      domains: ['aceternity.com', 'images.unsplash.com', 'assets.aceternity.com', 'ishankashamal.tech'],
    },
  }

export default nextConfig;
